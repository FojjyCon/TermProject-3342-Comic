﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using static System.Net.Mime.MediaTypeNames;
using static ComicSOAP.MarvelApi.Character;

namespace ComicSOAP.MarvelApi
{
    //this communicates with the Marvel API
    public class Marvel
    {
        private const string BASE_URL = "http://gateway.marvel.com/v1/public/";
        //get these two keys from the website
        private readonly string _publicKey = "7fe78693ca11a28d23d65b1e45722a27";
        private readonly string _privateKey = "0010eb29965b5e8b1d42b06b6fd8e841aa100373";
        private static HttpClient _client = new HttpClient();

        //gateway link that grabs all comics with the hashed md5 code at the end md5(ts + private + public) -> md5 generator to convert
        //http://gateway.marvel.com/v1/public/comics?ts=1&apikey=7fe78693ca11a28d23d65b1e45722a27&hash=66062f1219c21aafc3eda7d3b6ca78ee


        public Marvel()
        {
        
        }

        public async Task<CharacterDataWrapper> GetCharacters(string Name = null,
                                            string NameStartsWith = null,
                                            DateTime? ModifiedSince = null,
                                            IEnumerable<int> Comics = null,
                                            IEnumerable<int> Series = null,
                                            IEnumerable<int> Events = null,
                                            IEnumerable<int> Stories = null,
                                            IEnumerable<OrderBy> Order = null,
                                            int? Limit = null,
                                            int? Offset = null)
        {
            //we need a timestamp
            string timestamp = (DateTime.Now.ToUniversalTime() - new DateTime(1970, 1, 1)).TotalSeconds.ToString();
            //we need use a hash to call the marvel api
            string s = String.Format("{0}{1}{2}", timestamp, _privateKey, _publicKey);

            string hash = CreateHash(s);
            //format the url string  with search critieria          
            string requestURL = String.Format(BASE_URL + "/characters?ts={0}&apikey={1}&hash={2}&name={3}", timestamp, _publicKey, hash, Name);

            var url = new Uri(requestURL);

            var response = await _client.GetAsync(url);

            string json;
            using (var content = response.Content)
            {
                json = await content.ReadAsStringAsync();
            }

            CharacterDataWrapper cdw = JsonConvert.DeserializeObject<CharacterDataWrapper>(json);
            return cdw;
        }

        public async Task<ComicDataWrapper> GetComicsForCharacter(int CharacterId,
                                                        ComicFormat? Format = ComicFormat.Comic,
                                                        ComicFormatType? FormatType = ComicFormatType.Comic,
                                                        bool? NoVariants = null,
                                                        DateDescriptor? DateDescript = null,
                                                        DateTime? DateRangeBegin = null,
                                                        DateTime? DateRangeEnd = null,
                                                        bool? HasDigitalIssue = null,
                                                        DateTime? ModifiedSince = null,
                                                        IEnumerable<int> Creators = null,
                                                        IEnumerable<int> Series = null,
                                                        IEnumerable<int> Events = null,
                                                        IEnumerable<int> Stories = null,
                                                        IEnumerable<int> SharedAppearances = null,
                                                        IEnumerable<int> Collaborators = null,
                                                        IEnumerable<OrderBy> Order = null,
                                                        int? Limit = null,
                                                        int? Offset = null)
        {


            //we need a timestamp
            string timestamp = (DateTime.Now.ToUniversalTime() - new DateTime(1970, 1, 1)).TotalSeconds.ToString();
            //we need use a hash to call the marvel api
            string s = String.Format("{0}{1}{2}", timestamp, _privateKey, _publicKey);
            string hash = CreateHash(s);
            string requestURL = String.Format(BASE_URL + "/characters/{3}/comics?ts={0}&apikey={1}&hash={2}&format=comic&formatType=comic&limit=30", timestamp, _publicKey, hash, CharacterId);

            var url = new Uri(requestURL);

            var response = await _client.GetAsync(url);

            string json;
            using (var content = response.Content)
            {
                json = await content.ReadAsStringAsync();
            }

            ComicDataWrapper cdw = JsonConvert.DeserializeObject<ComicDataWrapper>(json);

            return cdw;
        }

        private string CreateHash(string input)
        {
            var hash = String.Empty;
            using (MD5 md5Hash = MD5.Create())
            {
                byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

                StringBuilder sBuilder = new StringBuilder();

                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                hash = sBuilder.ToString();
            }
            return hash;

        }
    }

    public class MarvelError
    {
        public string Code { get; set; }
        public string Message { get; set; }
    }

    public class MarvelUrl
    {
        public string Type { get; set; }
        public string Url { get; set; }
    }

    public class MarvelImage
    {
        public string Path { get; set; }
        public string Extension { get; set; }
        public override string ToString()
        {
            return string.Format("{0}.{1}", Path, Extension);
        }
        public string ToString(Image size)
        {
            return string.Format("{0}{1}.{2}", Path, size.ToParameter(), Extension);
        }
    }
    public class TextObject
    {
        public string Type { get; set; }
        public string Language { get; set; }
        public string Text { get; set; }
    }
}
