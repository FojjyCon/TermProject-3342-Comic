﻿namespace HeroSearch
{
    internal class MarvelApi
    {
    }
}