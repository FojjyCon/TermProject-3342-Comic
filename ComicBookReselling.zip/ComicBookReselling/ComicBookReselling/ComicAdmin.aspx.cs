﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ComicBookReselling
{
    public partial class ComicAdmin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUnban_Click(object sender, EventArgs e)
        {

        }

        protected void btnBan_Click(object sender, EventArgs e)
        {

        }

        protected void gvComicAccounts_SelectedIndexChanged(object sender, EventArgs e)
        {
            return;
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
            Session.Abandon();
        }

        protected void gvComicBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            return;
        }

        protected void gvComicBooks_RowCommand(object sender, EventArgs e)
        {
            return;
        }
    }
}