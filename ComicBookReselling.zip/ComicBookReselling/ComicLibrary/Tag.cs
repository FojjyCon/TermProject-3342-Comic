﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComicLibrary
{
    public class Tag
    {
        private String tagName;

        public String TagName { get { return tagName; } set { tagName = value; } }
    }
}
